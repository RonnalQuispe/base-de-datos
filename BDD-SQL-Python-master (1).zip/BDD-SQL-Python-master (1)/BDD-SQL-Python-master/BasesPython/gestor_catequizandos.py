import pyodbc
import json
from datetime import datetime

class GestorEstudiantes:
    def __init__(self):
        try:
            with open('config.json', 'r') as archivo_config:
                config = json.load(archivo_config)

            servidor = config.get('server')
            base_datos = config.get('database')

            self.conexion = pyodbc.connect(
                f"DRIVER={{SQL Server}};SERVER={servidor};DATABASE={base_datos};Trusted_Connection=yes;"
            )
            print("✅ Conexión exitosa a SQL Server.")
        except Exception as e:
            print(f"❌ Error al conectar: {e}")
            self.conexion = None

    # ==========================================================
    # VALIDACIONES
    # ==========================================================

    def validar_fecha(self, fecha_texto):
        try:
            datetime.strptime(fecha_texto, "%Y-%m-%d")
            return True
        except ValueError:
            return False

    def parroquia_existe(self, parroquia_id):
        cursor = self.conexion.cursor()
        cursor.execute("SELECT COUNT(*) FROM Parroquia WHERE idParroquia = ?", parroquia_id)
        return cursor.fetchone()[0] > 0

    def usuario_existe(self, usuario_id):
        cursor = self.conexion.cursor()
        cursor.execute("SELECT COUNT(*) FROM Usuario WHERE idUsuario = ?", usuario_id)
        return cursor.fetchone()[0] > 0

    # ==========================================================
    # CREACIÓN AUTOMÁTICA DE PARROQUIA (FUNCIONAL)
    # ==========================================================

    def crear_parroquia(self, parroquia_id):
        print("\n⚠️ La parroquia NO existe. Vamos a crearla automáticamente.")

        nombre = input("Ingrese el nombre de la nueva parroquia: ")
        direccion = input("Ingrese la dirección de la parroquia: ")
        telefono = input("Ingrese el teléfono: ")
        correo = input("Ingrese el correo: ")

        # PEDIR usuario existente
        usuario_id = int(input("Ingrese el ID de Usuario que CREÓ esta parroquia: "))

        # Validar usuario real
        if not self.usuario_existe(usuario_id):
            print("❌ Ese ID de Usuario NO existe. No se creará la parroquia.")
            return False

        try:
            cursor = self.conexion.cursor()
            cursor.execute("""
                INSERT INTO Parroquia (
                    idParroquia,
                    nombreParroquia,
                    dirreccion,
                    telefono,
                    correo,
                    Usuario_idUsuario
                )
                VALUES (?, ?, ?, ?, ?, ?)
            """, (parroquia_id, nombre, direccion, telefono, correo, usuario_id))

            self.conexion.commit()
            print("✅ Parroquia creada correctamente.")
            return True

        except Exception as e:
            print(f"❌ Error al crear parroquia: {e}")
            return False

    # ==========================================================
    # CRUD ESTUDIANTE
    # ==========================================================

    def insertar(self, idEstudiante, cedula, nombre, apellido,
                 fechaNacimiento, direccion, telefonoRep,
                 nombreRep, parroquia_id):

        if not self.validar_fecha(fechaNacimiento):
            print("⚠️ Fecha inválida (formato YYYY-MM-DD).")
            return

        # Validar parroquia
        if not self.parroquia_existe(parroquia_id):
            creada = self.crear_parroquia(parroquia_id)
            if not creada:
                print("❌ No se puede continuar sin una parroquia válida.")
                return

        try:
            cursor = self.conexion.cursor()
            cursor.execute("""
                INSERT INTO Estudiante (
                    idEstudiante, cedula, nombre, apellido, fechaNacimiento,
                    direccion, telefonoRepresentante, nombreRepresentante,
                    Parroquia_idParroquia
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (idEstudiante, cedula, nombre, apellido,
                  fechaNacimiento, direccion, telefonoRep,
                  nombreRep, parroquia_id))

            self.conexion.commit()
            print("✅ Estudiante insertado correctamente.")
        except Exception as e:
            print(f"❌ Error al insertar: {e}")

    # ==========================================================
    # CONSULTAS
    # ==========================================================

    def consultar_por_id(self, idEstudiante):
        try:
            cursor = self.conexion.cursor()
            cursor.execute("SELECT * FROM Estudiante WHERE idEstudiante = ?", idEstudiante)
            fila = cursor.fetchone()
            if fila:
                print("\n📌 Registro encontrado:")
                print(fila)
            else:
                print("⚠️ No existe un estudiante con ese ID.")
        except Exception as e:
            print(f"❌ Error al consultar: {e}")

    def consultar_todos(self):
        try:
            cursor = self.conexion.cursor()
            cursor.execute("SELECT * FROM Estudiante")
            filas = cursor.fetchall()

            print("\n📋 LISTADO DE ESTUDIANTES:")
            for fila in filas:
                print(fila)

        except Exception as e:
            print(f"❌ Error al consultar todos: {e}")

    # ==========================================================
    # ACTUALIZAR / ELIMINAR
    # ==========================================================

    def actualizar(self, idEstudiante, cedula, nombre, apellido,
                   fechaNacimiento, direccion, telefonoRep, nombreRep):

        if not self.validar_fecha(fechaNacimiento):
            print("⚠️ Fecha inválida.")
            return

        try:
            cursor = self.conexion.cursor()
            cursor.execute("""
                UPDATE Estudiante
                SET cedula=?, nombre=?, apellido=?, fechaNacimiento=?,
                    direccion=?, telefonoRepresentante=?, nombreRepresentante=?
                WHERE idEstudiante=?
            """, (cedula, nombre, apellido, fechaNacimiento,
                  direccion, telefonoRep, nombreRep, idEstudiante))

            self.conexion.commit()
            print("✅ Registro actualizado correctamente.")
        except Exception as e:
            print(f"❌ Error al actualizar: {e}")

    def eliminar(self, idEstudiante):
        try:
            cursor = self.conexion.cursor()
            cursor.execute("DELETE FROM Estudiante WHERE idEstudiante = ?", idEstudiante)
            self.conexion.commit()
            print("🗑️ Registro eliminado.")
        except Exception as e:
            print(f"❌ Error al eliminar: {e}")

    # ==========================================================
    # MENÚ
    # ==========================================================

    def ejecutar_menu(self):
        if not self.conexion:
            print("❌ No hay conexión disponible.")
            return

        while True:
            print("\n\t** SISTEMA CRUD ESTUDIANTES **")
            print("1. Insertar estudiante")
            print("2. Consultar por ID")
            print("3. Listar todos")
            print("4. Actualizar")
            print("5. Eliminar")
            print("6. Salir")

            opcion = input("Seleccione una opción: ")

            if opcion == "1":
                print("\n--- NUEVO ESTUDIANTE ---")

                idE = int(input("ID estudiante: "))
                ced = input("Cédula: ")
                nom = input("Nombre: ")
                ape = input("Apellido: ")
                fecha = input("Fecha nacimiento (YYYY-MM-DD): ")
                dirr = input("Dirección: ")
                tel = input("Teléfono representante: ")
                repr = input("Nombre representante: ")
                parroq = int(input("ID Parroquia: "))

                self.insertar(idE, ced, nom, ape, fecha, dirr, tel, repr, parroq)

            elif opcion == "2":
                idE = int(input("ID a consultar: "))
                self.consultar_por_id(idE)

            elif opcion == "3":
                self.consultar_todos()

            elif opcion == "4":
                idE = int(input("ID estudiante a actualizar: "))
                ced = input("Nueva cédula: ")
                nom = input("Nuevo nombre: ")
                ape = input("Nuevo apellido: ")
                fecha = input("Nueva fecha (YYYY-MM-DD): ")
                dirr = input("Nueva dirección: ")
                tel = input("Nuevo teléfono representante: ")
                repr = input("Nuevo nombre representante: ")

                self.actualizar(idE, ced, nom, ape, fecha, dirr, tel, repr)

            elif opcion == "5":
                idE = int(input("ID estudiante a eliminar: "))
                self.eliminar(idE)

            elif opcion == "6":
                print("👋 Saliendo...")
                break

            else:
                print("⚠️ Opción inválida.")


if __name__ == "__main__":
    app = GestorEstudiantes()
    app.ejecutar_menu()
