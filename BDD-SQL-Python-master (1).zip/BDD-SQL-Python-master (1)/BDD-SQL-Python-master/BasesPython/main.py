from gestor_estudiantes import GestorEstudiantes

if __name__ == "__main__":
    gestor = GestorEstudiantes()
    gestor.ejecutar_menu()
